#ifndef TESTRNCOLLECTION_H
#define TESTRNCOLLECTION_H

void runCollectionTests();

#endif // TESTRNCOLLECTION_H
